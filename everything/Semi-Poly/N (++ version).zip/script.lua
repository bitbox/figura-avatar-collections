RootGroup = models.model.root
anims = require("libs.JimmyAnims")
anims(animations.model)

local SwingingPhysics = require("libs.swinging_physics")
local swingOnHead = SwingingPhysics.swingOnHead
local swingOnBody = SwingingPhysics.swingOnBody

require("libs.GSAnimBlend")
require("colors")


-- Auto generated script file --

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)

--re-enable the helmet item
vanilla_model.HELMET_ITEM:setVisible(true)

--hide vanilla cape model
vanilla_model.CAPE:setVisible(false)

--hide vanilla elytra model
vanilla_model.ELYTRA:setVisible(false)

--entity init event, used for when the avatar entity is loaded for the first time
function events.entity_init()
  --player functions goes here

  Headband_trail = {
    RootGroup.Head.headband1,
    RootGroup.Head.headband1.headband2,
    RootGroup.Head.headband1.headband2.headband3,
    RootGroup.Head.headband1.headband2.headband3.headband4,
    RootGroup.Head.headband1.headband2.headband3.headband4.headband5,
    RootGroup.Head.headband1.headband2.headband3.headband4.headband5.headband6,
    RootGroup.Head.headband1.headband2.headband3.headband4.headband5.headband6.headband7,
    RootGroup.Head.headband1.headband2.headband3.headband4.headband5.headband6.headband7.headband8
  }
 
  BoneHB_List = {
    BoneHeadband1 = nil,
    BoneHeadband2 = nil,
    BoneHeadband3 = nil,
    BoneHeadband4 = nil,
    BoneHeadband5 = nil,
    BoneHeadband6 = nil,
    BoneHeadband7 = nil,
    BoneHeadband8 = nil,
    BoneHeadband9 = nil,
    BoneHeadband10 = nil,
    BoneHeadband11 = nil,
    BoneHeadband12 = nil,
    BoneHeadband13 = nil,
    BoneHeadband14 = nil,
    BoneHeadband15 = nil,
    BoneHeadband16 = nil,
  }

  swingOnHead(Headband_trail[1], 270, nil)

  for i=1,#Headband_trail do
    --old code incoming
    --[[ --"Elegance is coming lmao" That's called a shower thought.
    BoneHB_List[i] = Headband_trail[i]:newPhysBone("physBone") -- Looks at the list of bones, to the list of variables.
    --"TWO TABLES ARE HELPING ME OUT." As if it needed h2o to activate that.

    BoneHB_List[i] --CONFIGURATION (I love customization.)
      :setGravity(-9.8)
      :setAirResistance(1)
      :setMass(0.5) ]]

    local bandLimits = {(-90 + ((i - 1) * 13)),(90 - ((i - 1) * 15)),0,0,0,0}

    if not (i >= #Headband_trail) then
      swingOnBody(Headband_trail[i+1], (i / 4), bandLimits, Headband_trail[i], (i/2))
    end
  end

  animations.model.idle:setBlendTime(0)
  animations.model.walk:setBlendTime(0)
  animations.model.jumpup:setBlendTime(0.1,6)
  animations.model.jumpdown:setBlendTime(6,0.1)
  animations.model.sprintjumpup:setBlendTime(0.1,6)
  animations.model.sprintjumpdown:setBlendTime(6,0.1)
  
  if player:isLoaded() then
    -- when the textures hurt me
    local textureList = {
      textures["model.ninja"],
      textures["model.headband"],
      textures["tex.ninja"],
      textures["tex.headband"]
    }

    if (textureList[1] or textureList[2]) == not nil then
    --customize your look with CODE
    textureList[1]:fill(0, 0, 2, 2, Colors.BodyColor_RGBA)
      :update()

    -- i mean it
    textureList[2]:fill(0, 0, 2, 2, Colors.HeadbandColor_RGBA)
      :update()
    else -- fuck this beta.
      textureList[3]:fill(0, 0, 2, 2, Colors.BodyColor_RGBA)
        :update()
        
      -- they're making me look at the tex directory.
      textureList[4]:fill(0, 0, 2, 2, Colors.HeadbandColor_RGBA)
        :update()
    end
    --print("Hey you! Do ya hate the brightness of this ninja? \n Well, we got a solution for you! Just edit the \"Edit\" table in the colors.lua file to see immediate vibes.")
  end
end

--tick event, called 20 times per second

function events.tick()
  --code goes here
end

--"render event, called every time your avatar is rendered"
-- i aint readin allat.
function events.render(delta, context)
  --code goes here
  animations.model.walk:setSpeed((player:getVelocity().xz:length() * 9))
  
end
