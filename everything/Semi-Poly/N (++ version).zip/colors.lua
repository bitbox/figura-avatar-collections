--Here's how it works:
Edit = { --edit these in the colors.lua file
    -- Headband colors
    255, -- the red for the headband
    0, -- the green
    59, -- the blue
    255, --lemme be clear. *turns into glass*

    -- Body colors
    255, -- you know the drill by now.
    255, -- 255 is max, 0 is none at all
    255, -- even for blue
    255, -- 255 is solid, or opaque. 0 is as visible as your father when he went out for milk.
}

-- you can change any of those values to whatever you want.
-- just remember to not touch what's below unless you're really good at lua and can help me get this to be better.
-- or if you're GS or jimmy. they're just waaaaay too baller to be complimented enough.

--anyways, MAGIC++
fresh = {0.0,0.0,0.0,0.0,0.0,0.0,0.0} -- this is for the for loop
for i=1,8 do
    fresh[i] = (Edit[i] / 255) -- and this is how I tell my computer to shut up about decimals.
end

Colors = { -- the table for all colors that can be changed.
    HeadbandColor_RGBA = vec(fresh[1], fresh[2], fresh[3], fresh[4]), -- (255, 0, 59) as in 255 red, 0 green, and 59 blue. that last value is opacity (how clear it is.)
    BodyColor_RGBA = vec(fresh[5], fresh[6], fresh[7], fresh[8]), -- max all values to get white.
}

return Colors